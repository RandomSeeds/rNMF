#' rnmf
#'
#' @name rnmf
#' @docType package
NULL
