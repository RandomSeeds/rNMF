## l2 norm.
l2 <- function(x){ return(sqrt(sum(x^2)))}     
