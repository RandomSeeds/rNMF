find.y = function(i, p){ return((i-1) %/% p + 1)}
