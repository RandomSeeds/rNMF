find.x = function(i, p){ return((i-1) %% p + 1)}
